﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public enum Token_Class
{
    Begin, Call, Declare, End, Do, Else, EndIf, EndUntil, EndWhile, If, Integer, Float,
    Parameters, Procedure, Program, Read, Real, Set, Then, Until, While, Write,
    Dot, Semicolon, Comma, LParanthesis, RParanthesis, EqualOp, LessThanOp,
    GreaterThanOp, NotEqualOp, PlusOp, MinusOp, MultiplyOp, DivideOp,
    Identifier, Constant, String, Repeat, ElseIf, Return, EndL, Main, LBrace,
    RBrace, AssignmentOp, AND_Op, OR_Op
}

namespace JASON_Compiler
{
    public class Token
    {
        public string lex;
        public Token_Class token_type;
    }

    public class Scanner
    {
        public List<Token> Tokens = new List<Token>();
        Dictionary<string, Token_Class> ReservedWords = new Dictionary<string, Token_Class>();
        Dictionary<string, Token_Class> Operators = new Dictionary<string, Token_Class>();

        public Scanner()
        {
            ReservedWords.Add("if", Token_Class.If);
            ReservedWords.Add("end", Token_Class.End);
            ReservedWords.Add("endl", Token_Class.EndL);
            ReservedWords.Add("else", Token_Class.Else);
            ReservedWords.Add("int", Token_Class.Integer);
            ReservedWords.Add("float", Token_Class.Float);
            ReservedWords.Add("string", Token_Class.String);
            ReservedWords.Add("repeat", Token_Class.Repeat);
            ReservedWords.Add("elseif", Token_Class.ElseIf);
            ReservedWords.Add("return", Token_Class.Return);
            ReservedWords.Add("then", Token_Class.Then);
            ReservedWords.Add("until", Token_Class.Until);
            ReservedWords.Add("write", Token_Class.Write);
            ReservedWords.Add("main", Token_Class.Main);
            ReservedWords.Add("read", Token_Class.Read);
            ReservedWords.Add("while", Token_Class.While);
            ReservedWords.Add("parameters", Token_Class.Parameters);
            ReservedWords.Add("procedure", Token_Class.Procedure);
            ReservedWords.Add("program", Token_Class.Program);
            ReservedWords.Add("real", Token_Class.Real);
            ReservedWords.Add("set", Token_Class.Set);
            ReservedWords.Add("endif", Token_Class.EndIf);
            ReservedWords.Add("enduntil", Token_Class.EndUntil);
            ReservedWords.Add("endwhile", Token_Class.EndWhile);
            ReservedWords.Add("do", Token_Class.Do);
            ReservedWords.Add("call", Token_Class.Call);
            ReservedWords.Add("declare", Token_Class.Declare);
            ReservedWords.Add("begin", Token_Class.Begin);

            Operators.Add(".", Token_Class.Dot);
            Operators.Add(";", Token_Class.Semicolon);
            Operators.Add(",", Token_Class.Comma);
            Operators.Add("(", Token_Class.LParanthesis);
            Operators.Add(")", Token_Class.RParanthesis);
            Operators.Add("=", Token_Class.EqualOp);
            Operators.Add("+", Token_Class.PlusOp);
            Operators.Add("-", Token_Class.MinusOp);
            Operators.Add("–", Token_Class.MinusOp);
            Operators.Add("—", Token_Class.MinusOp);
            Operators.Add("−", Token_Class.MinusOp);
            Operators.Add("*", Token_Class.MultiplyOp);
            Operators.Add("/", Token_Class.DivideOp);
            Operators.Add("<", Token_Class.LessThanOp);
            Operators.Add(">", Token_Class.GreaterThanOp);
            Operators.Add("{", Token_Class.LBrace);
            Operators.Add("}", Token_Class.RBrace);
            Operators.Add(":=", Token_Class.AssignmentOp);
            Operators.Add("<>", Token_Class.NotEqualOp);
        }
        public void StartScanning(string SourceCode)
        {
            for (int i = 0; i < SourceCode.Length; i++)
            {
                int j = i;
                char CurrentChar = SourceCode[i];
                string CurrentLexeme = CurrentChar.ToString();

                if (CurrentChar == ' ' || CurrentChar == '\r' || CurrentChar == '\n' || CurrentChar == '\t')
                    continue;

                else if (CurrentChar == '.')
                {
                    if (i + 1 < SourceCode.Length && SourceCode[i + 1] >= '0' && SourceCode[i + 1] <= '9')
                    {
                        string invalidNum = ".";
                        i++;

                        while (i < SourceCode.Length && SourceCode[i] >= '0' && SourceCode[i] <= '9')
                        {
                            invalidNum += SourceCode[i];
                            i++;
                        }

                        Errors.Error_List.Add($"Invalid number format: '{invalidNum}'");
                        i--;
                    }
                    else
                    {
                        Token t = new Token();
                        t.lex = ".";
                        t.token_type = Token_Class.Dot;
                        Tokens.Add(t);
                    }
                }

                else if ((CurrentChar >= 'A' && CurrentChar <= 'Z') || (CurrentChar >= 'a' && CurrentChar <= 'z'))
                {
                    string lex = "";

                    while (i < SourceCode.Length &&
                          ((SourceCode[i] >= 'A' && SourceCode[i] <= 'Z') ||
                           (SourceCode[i] >= 'a' && SourceCode[i] <= 'z') ||
                           (SourceCode[i] >= '0' && SourceCode[i] <= '9')))
                    {
                        lex += SourceCode[i];
                        i++;
                    }
                    i--;
                    FindTokenClass(lex);
                }

                else if (CurrentChar >= '0' && CurrentChar <= '9')
                {
                    string numberLex = "";
                    bool hasDecimal = false;
                    bool error = false;
                    int startPos = i;

                    numberLex += CurrentChar;
                    i++;

                    while (i < SourceCode.Length)
                    {
                        char c = SourceCode[i];

                        if (c >= '0' && c <= '9')
                        {
                            numberLex += c;
                            i++;
                        }
                        else if (c == '.')
                        {

                            if (hasDecimal)
                            {
                                error = true;
                                numberLex += c;
                                i++;
                                continue;
                            }

                            hasDecimal = true;
                            numberLex += c;
                            i++;
                        }
                        else if (c == ' ' || c == '\r' || c == '\n' || c == '\t')
                        {
                            break;
                        }
                        else if (Operators.ContainsKey(c.ToString()))
                        {
                            break;
                        }
                        else
                        {

                            error = true;
                            while (i < SourceCode.Length &&
                                   SourceCode[i] != ' ' && SourceCode[i] != '\r' &&
                                   SourceCode[i] != '\n' && SourceCode[i] != '\t')
                            {
                                numberLex += SourceCode[i];
                                i++;
                            }
                            break;
                        }
                    }

                    if (!error)
                    {

                        if (hasDecimal && numberLex.EndsWith("."))
                        {
                            error = true;
                        }

                        if (hasDecimal && !error)
                        {
                            string[] parts = numberLex.Split('.');
                            if (parts.Length != 2 || parts[0].Length == 0 || parts[1].Length == 0)
                            {
                                error = true;
                            }
                        }
                    }

                    if (!error)
                    {
                        Token t = new Token();
                        t.lex = numberLex;
                        t.token_type = hasDecimal ? Token_Class.Real : Token_Class.Constant;
                        Tokens.Add(t);
                    }
                    else
                    {
                        Errors.Error_List.Add($"Invalid number format: '{numberLex}'");
                    }

                    i--;
                }
                else if (CurrentChar == '{' || CurrentChar == '}')
                {
                    Token t = new Token();
                    t.lex = CurrentChar.ToString();
                    t.token_type = Operators[CurrentChar.ToString()];
                    Tokens.Add(t);
                }

                else if (CurrentChar == '"')
                {
                    string stringLex = "";
                    bool closed = false;
                    int startPos = i;
                    i++;

                    while (i < SourceCode.Length)
                    {
                        if (SourceCode[i] == '"')
                        {
                            closed = true;
                            i++;
                            break;
                        }
                        else
                        {
                            stringLex += SourceCode[i];
                            i++;
                        }
                    }

                    if (closed)
                    {
                        Token t = new Token();
                        t.lex = "\"" + stringLex + "\"";
                        t.token_type = Token_Class.String;
                        Tokens.Add(t);
                    }
                    else
                    {
                        Errors.Error_List.Add("Unclosed string: \"" + stringLex);

                    }
                    i--;
                }

                else if (CurrentChar == '/' && i + 1 < SourceCode.Length && SourceCode[i + 1] == '*')
                {
                    string commentLex = "/*";
                    i += 2;

                    bool commentClosed = false;

                    while (i < SourceCode.Length)
                    {
                        if (SourceCode[i] == '*')
                        {
                            commentLex += '*';
                            i++;
                            while (i < SourceCode.Length && SourceCode[i] == '*')
                            {
                                commentLex += '*';
                                i++;
                            }

                            if (i < SourceCode.Length && SourceCode[i] == '/')
                            {
                                commentLex += '/';
                                i++;
                                commentClosed = true;
                                break;
                            }
                        }
                        else
                        {
                            commentLex += SourceCode[i];
                            i++;
                        }
                    }

                    if (!commentClosed)
                        Errors.Error_List.Add($"Unclosed comment: '{commentLex}'");

                    i--;
                }

                else if (CurrentChar == '<')
                {
                    if (i + 1 < SourceCode.Length && SourceCode[i + 1] == '>')
                    {
                        i++;
                        Token t = new Token();
                        t.lex = "<>";
                        t.token_type = Token_Class.NotEqualOp;
                        Tokens.Add(t);
                    }
                    else
                    {
                        Token t = new Token();
                        t.lex = "<";
                        t.token_type = Token_Class.LessThanOp;
                        Tokens.Add(t);
                    }
                }

                else if (CurrentChar == '>')
                {
                    Token t = new Token();
                    t.lex = ">";
                    t.token_type = Token_Class.GreaterThanOp;
                    Tokens.Add(t);
                }

                else if (CurrentChar == '&')
                {
                    if (i + 1 < SourceCode.Length && SourceCode[i + 1] == '&')
                    {
                        i++;
                        Token t = new Token();
                        t.lex = "&&";
                        t.token_type = Token_Class.AND_Op;
                        Tokens.Add(t);
                    }
                    else
                    {
                        Errors.Error_List.Add($"Unrecognised character: '&' (did you mean '&&'?)");
                    }
                }

                else if (CurrentChar == '|')
                {
                    if (i + 1 < SourceCode.Length && SourceCode[i + 1] == '|')
                    {
                        i++;
                        Token t = new Token();
                        t.lex = "||";
                        t.token_type = Token_Class.OR_Op;
                        Tokens.Add(t);
                    }
                    else
                    {
                        Errors.Error_List.Add($"Unrecognised character: '|' (did you mean '||'?)");
                    }
                }

                else if (CurrentChar == '+')
                {
                    Token t = new Token();
                    t.lex = "+";
                    t.token_type = Token_Class.PlusOp;
                    Tokens.Add(t);
                }
                else if (CurrentChar == '-')
                {
                    Token t = new Token();
                    t.lex = "-";
                    t.token_type = Token_Class.MinusOp;
                    Tokens.Add(t);
                }
                else if (CurrentChar == '*')
                {
                    Token t = new Token();
                    t.lex = "*";
                    t.token_type = Token_Class.MultiplyOp;
                    Tokens.Add(t);
                }

                else if ((CurrentChar == '/') && ((i + 1 < SourceCode.Length) && (SourceCode[i + 1] != '*')))
                {
                    Token t = new Token();
                    t.lex = "/";
                    t.token_type = Token_Class.DivideOp;
                    Tokens.Add(t);
                }

                else if ((CurrentChar == ':') && ((i + 1 < SourceCode.Length) && (SourceCode[i + 1] == '=')))
                {
                    Token t = new Token();
                    t.lex = ":=";
                    t.token_type = Token_Class.AssignmentOp;
                    Tokens.Add(t);
                    i++;
                }

                else if (Operators.ContainsKey(CurrentChar.ToString()))
                {
                    Token t = new Token();
                    t.lex = CurrentChar.ToString();
                    t.token_type = Operators[CurrentChar.ToString()];
                    Tokens.Add(t);
                }

                else
                {
                    Errors.Error_List.Add($"Unrecognised character: '{CurrentChar}'");
                }
            }
        }
        void FindTokenClass(string Lex)
        {
            Token Tok = new Token();
            Tok.lex = Lex;

            if (ReservedWords.ContainsKey(Lex))
            {
                Tok.token_type = ReservedWords[Lex];
            }
            else if (isIdentifier(Lex))
            {
                Tok.token_type = Token_Class.Identifier;
            }

            else
            {
                Errors.Error_List.Add("Undefined token: " + Lex);
            }
            Tokens.Add(Tok);
        }
        bool isIdentifier(string lex)
        {
            if ((lex[0] >= 'A' && lex[0] <= 'Z') || (lex[0] >= 'a' && lex[0] <= 'z'))
                return true;

            Errors.Error_List.Add("Identifier doesn't start with a letter: " + lex);
            return false;
        }

        bool isConstant(string lex)
        {
            bool isValid = true;
            return isValid;
        }
    }
}